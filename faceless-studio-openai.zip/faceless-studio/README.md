# Faceless Studio
Riset niche per negara -> script -> terjemah -> voiceover -> video -> subtitle -> thumbnail -> upload YT/IG/FB/TikTok. Multi-channel.

## Setup
    pip install -r requirements.txt && cp .env.example .env   # isi key; butuh ffmpeg
    python -m studio.cli report "personal finance" US          # deep research
    python -m studio.cli produce                               # buat video batch
    python -m studio.cli review && python -m studio.cli approve 1
    python -m studio.cli publish
    # jalan otomatis: crontab -> 0 6 * * * cd /path && python -m studio.cli daily

## Catatan penting
- Token OAuth YouTube per channel -> `tokens/<id>.json` (buat sekali via google-auth-oauthlib).
- Visual default stok Pexels. Untuk video model terbaik + motion control, isi adapter `clip()` di `studio/media.py` (Veo/Runway/Kling: kirim `visual_prompt` + `camera_motion`).
- IG & TikTok butuh `PUBLIC_BASE_URL` yang menyajikan folder `output/`. TikTok default `SELF_ONLY` sampai app audit lolos.
- `auto_publish: false` sengaja jadi default: YouTube menolak monetisasi konten massal/repetitif tanpa nilai orisinal. Review manusia + angle orisinal = kunci lolos YPP. Disclosure konten sintetis sudah dinyalakan.
- Angka RPM di `config/markets.yaml` hanya estimasi awal; ganti dengan data Analytics-mu.
