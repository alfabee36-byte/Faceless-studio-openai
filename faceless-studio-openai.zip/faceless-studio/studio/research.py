"""Riset niche & topik per negara: sinyal nyata dari YouTube + analisis LLM."""
import os, requests, yaml
from .llm import ask_json
YT = "https://www.googleapis.com/youtube/v3"
def market(code): return yaml.safe_load(open("config/markets.yaml"))[code]
def yt_signals(niche, region, n=25):
    k = os.environ["YOUTUBE_API_KEY"]
    s = requests.get(f"{YT}/search", params=dict(part="snippet", q=niche, type="video", order="viewCount",
        regionCode=region, maxResults=n, key=k)).json().get("items", [])
    ids = ",".join(i["id"]["videoId"] for i in s)
    v = requests.get(f"{YT}/videos", params=dict(part="snippet,statistics", id=ids, key=k)).json().get("items", [])
    return [dict(title=x["snippet"]["title"], channel=x["snippet"]["channelTitle"],
                 views=int(x["statistics"].get("viewCount", 0))) for x in v]
def market_report(niche, mk):
    """Deep research per negara: audiens, musim, kompetitor, celah topik, risiko kebijakan."""
    m = market(mk); sig = yt_signals(niche, m["region"])
    return ask_json("You are a YouTube market analyst for monetized faceless channels.",
        f"Niche: {niche}\nCountry: {mk} (tier {m['tier']}, est RPM {m['rpm']} USD)\nTop competitor videos: {sig}\n"
        "Return JSON: {audience:{demographics,pain_points,search_behavior}, seasonality:[...], "
        "competitor_patterns:[...], content_gaps:[...], high_rpm_keywords:[...], risks:[...], "
        "topics:[{title,keyword,angle,est_search_intent,rpm_score_1_10}]} with 15 topics.", 6000)
def pick_topics(niche, mk, used, k):
    rep = market_report(niche, mk)
    t = [x for x in sorted(rep["topics"], key=lambda x: -x["rpm_score_1_10"]) if x["title"] not in used]
    return rep, t[:k]
