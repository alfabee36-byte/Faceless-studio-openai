from .llm import ask_json
def write(topic, niche, mk, fmt):
    dur = "45-58 seconds" if fmt == "short" else "7-9 minutes"
    return ask_json("You write original, factual, human-sounding faceless video scripts. No filler, no false clickbait, "
        "concrete facts, varied rhythm, an original angle (never reused content).",
        f"Topic: {topic['title']} | angle: {topic['angle']} | niche: {niche} | audience: {mk} | length: {dur}\n"
        "JSON: {title, description, tags:[...], hook, scenes:[{narration, visual_prompt, camera_motion}], "
        "thumbnail:{text, visual_prompt}}. visual_prompt = realistic, cinematic, photoreal, specific.", 6000)
