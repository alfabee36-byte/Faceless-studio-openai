import sqlite3, json
c = sqlite3.connect("studio.db")
c.execute("""create table if not exists jobs(id integer primary key, channel text, topic text,
 lang text, status text, path text, meta text, created text default current_timestamp)""")
def add(channel, topic, lang, status, path, meta):
    cur = c.execute("insert into jobs(channel,topic,lang,status,path,meta) values(?,?,?,?,?,?)",
                    (channel, topic, lang, status, path, json.dumps(meta))); c.commit(); return cur.lastrowid
def set_status(i, s): c.execute("update jobs set status=? where id=?", (s, i)); c.commit()
def by_status(s): return c.execute("select id,channel,topic,lang,path,meta from jobs where status=?", (s,)).fetchall()
def used_topics(ch): return {r[0] for r in c.execute("select topic from jobs where channel=?", (ch,))}
