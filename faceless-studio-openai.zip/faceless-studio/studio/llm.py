import os, json, re
from openai import OpenAI

def _client():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY belum diatur. Salin .env.example menjadi .env "
            "dan isi OPENAI_API_KEY dari https://platform.openai.com/api-keys."
        )
    return OpenAI(api_key=api_key)

def ask(system, prompt, max_tokens=4000):
    response = _client().chat.completions.create(
        model=os.getenv("OPENAI_MODEL", "gpt-4.1"),
        max_tokens=max_tokens,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ],
    )
    content = response.choices[0].message.content
    if not content:
        raise RuntimeError("OpenAI API mengembalikan respons kosong.")
    return content

def ask_json(system, prompt, max_tokens=4000):
    t = ask(system + "\\nReturn ONLY valid JSON.", prompt, max_tokens)
    match = re.search(r"[\\[{].*[\\]}]", t, re.S)
    if not match:
        raise ValueError(f"Respons model bukan JSON yang valid: {t[:500]}")
    return json.loads(match.group(0))
