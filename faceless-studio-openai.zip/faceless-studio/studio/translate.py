from .llm import ask_json
def localize(script, lang):
    """Terjemah + lokalisasi budaya (bukan literal); jumlah scene tetap."""
    return ask_json(f"Native {lang} localizer. Adapt idioms, currency, examples to a {lang} audience.",
        f"Localize narration, title, description, tags, thumbnail.text into '{lang}'. Keep visual_prompt, camera_motion, scene count.\n{script}", 6000)
